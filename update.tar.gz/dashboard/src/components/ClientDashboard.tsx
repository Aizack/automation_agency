import React, { useState, useEffect } from 'react';
import { authFetch as fetch } from '../utils/api';
import { SaaSErpInventory } from './SaaSErpInventory';
import { SaaSErpInvoices } from './SaaSErpInvoices';
import { SaaSErpAppointments } from './SaaSErpAppointments';
import { SaaSErpEmployees } from './SaaSErpEmployees';
import { SaaSErpCRM } from './SaaSErpCRM';
import { SystemAlertsPanel } from './SystemAlertsPanel';

interface Client {
  id: string;
  name: string;
  phoneNumber: string;
  systemPrompt: string;
  activeTools: string[];
  status: string;
  agentPhone?: string;
  driveFolderId?: string;
  logo_url?: string;
  category?: string;
}

interface Interaction {
  sender_phone: string;
  message_text: string;
  response_text: string;
  api_cost: string;
  timestamp: string;
}

interface WhatsappStatus {
  status: string; // 'DISCONNECTED', 'QR', 'CONNECTED'
  qr: string;
  phone: string;
}

interface AgentContact {
  id: string;
  name: string;
  phone: string;
  priority: number;
  status: 'online' | 'offline';
}

interface AudioContact {
  tag: string;
  fileName: string;
  size: number;
  url: string;
}

interface ClientDashboardProps {
  clientId: string;
  onBack: () => void;
}

export const ClientDashboard: React.FC<ClientDashboardProps> = ({ clientId, onBack }) => {
  const [clientData, setClientData] = useState<Client | null>(null);
  const [activeTab, setActiveTab] = useState<'resumen' | 'inventario' | 'facturacion' | 'agenda' | 'empleados' | 'clientes' | 'logs'>('resumen');
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [loading, setLoading] = useState(true);

  // Tema Claro / Oscuro
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    const initialTheme = savedTheme || 'light';
    setTheme(initialTheme);
    document.documentElement.setAttribute('data-theme', initialTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  // Estado de WhatsApp en tiempo real
  const [whatsappStatus, setWhatsappStatus] = useState<WhatsappStatus>({
    status: 'DISCONNECTED',
    qr: '',
    phone: '',
  });

  // Estados del Formulario de Configuración
  const [systemPrompt, setSystemPrompt] = useState('');
  const [agentPhone, setAgentPhone] = useState('');
  const [driveFolderId, setDriveFolderId] = useState('');
  const [toneOfVoice, setToneOfVoice] = useState('Friendly');
  const [category, setCategory] = useState('optica');
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  // Estados para edición en caliente del teléfono del Bot
  const [isEditingPhone, setIsEditingPhone] = useState(false);
  const [tempPhone, setTempPhone] = useState('');
  
  // Estados para sincronización de Drive
  const [syncingDrive, setSyncingDrive] = useState(false);
  const [syncResult, setSyncResult] = useState<string | null>(null);

  // Estados para visor y carga de archivos del cliente
  const [uploadedFiles, setUploadedFiles] = useState<Array<{id: string, name: string, mimeType: string}>>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  // Estados para gestión de asesores humanos (escalamiento)
  const [agents, setAgents] = useState<AgentContact[]>([]);
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentPhone, setNewAgentPhone] = useState('');
  const [newAgentPriority, setNewAgentPriority] = useState<number>(1);
  const [loadingAgents, setLoadingAgents] = useState(false);

  // Estados para gestión de audios pregrabados
  const [audios, setAudios] = useState<AudioContact[]>([]);
  const [newAudioTag, setNewAudioTag] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [uploadingAudio, setUploadingAudio] = useState(false);
  const [loadingAudios, setLoadingAudios] = useState(false);

  // Cargar audios
  const fetchAudios = async () => {
    try {
      setLoadingAudios(true);
      const res = await fetch(`/api/clients/${clientId}/audios`);
      const json = await res.json();
      if (json.success) {
        setAudios(json.data || []);
      }
    } catch (err) {
      console.error("Error cargando audios:", err);
    } finally {
      setLoadingAudios(false);
    }
  };

  // Subir audio
  const handleUploadAudio = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAudioTag || !audioFile) return;

    const formData = new FormData();
    formData.append('etiqueta', newAudioTag.trim().toLowerCase().replace(/[^a-z0-9_]/g, ''));
    formData.append('audio', audioFile);

    setUploadingAudio(true);
    try {
      const res = await fetch(`/api/clients/${clientId}/audios`, {
        method: 'POST',
        body: formData
      });
      const json = await res.json();
      if (json.success) {
        setNewAudioTag('');
        setAudioFile(null);
        const fileInput = document.getElementById('audio-file-input') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
        fetchAudios();
      }
    } catch (err) {
      console.error("Error subiendo audio:", err);
    } finally {
      setUploadingAudio(false);
    }
  };

  // Eliminar audio
  const handleDeleteAudio = async (fileName: string) => {
    if (!confirm("¿Estás seguro de que deseas eliminar este audio?")) return;
    try {
      const res = await fetch(`/api/clients/${clientId}/audios/${fileName}`, {
        method: 'DELETE'
      });
      const json = await res.json();
      if (json.success) {
        fetchAudios();
      }
    } catch (err) {
      console.error("Error eliminando audio:", err);
    }
  };

  // Cargar asesores del cliente
  const fetchAgents = async () => {
    try {
      setLoadingAgents(true);
      const res = await fetch(`/api/clients/${clientId}/agents`);
      const json = await res.json();
      if (json.success) {
        setAgents(json.data || []);
        setNewAgentPriority(json.data ? json.data.length + 1 : 1);
      }
    } catch (err) {
      console.error("Error cargando asesores:", err);
    } finally {
      setLoadingAgents(false);
    }
  };

  // Agregar asesor
  const handleAddAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAgentName || !newAgentPhone) return;
    try {
      const res = await fetch(`/api/clients/${clientId}/agents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newAgentName,
          phone: newAgentPhone.trim(),
          priority: newAgentPriority
        })
      });
      const json = await res.json();
      if (json.success) {
        setNewAgentName('');
        setNewAgentPhone('');
        fetchAgents();
      }
    } catch (err) {
      console.error("Error agregando asesor:", err);
    }
  };

  // Eliminar asesor
  const handleDeleteAgent = async (agentId: string) => {
    if (!confirm("¿Estás seguro de que deseas eliminar este asesor de la lista de escalamiento?")) return;
    try {
      const res = await fetch(`/api/clients/${clientId}/agents/${agentId}`, {
        method: 'DELETE'
      });
      const json = await res.json();
      if (json.success) {
        fetchAgents();
      }
    } catch (err) {
      console.error("Error eliminando asesor:", err);
    }
  };

  // Cambiar estado de disponibilidad del asesor
  const handleToggleAgentStatus = async (agentId: string, currentStatus: 'online' | 'offline') => {
    const nextStatus = currentStatus === 'online' ? 'offline' : 'online';
    try {
      const res = await fetch(`/api/clients/${clientId}/agents/${agentId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      const json = await res.json();
      if (json.success) {
        fetchAgents();
      }
    } catch (err) {
      console.error("Error actualizando estado del asesor:", err);
    }
  };

  // Solicitar arranque de conexión de WhatsApp
  const handleConnectWhatsApp = async () => {
    try {
      await fetch(`/api/whatsapp/connect?clientId=${clientId}`, { method: 'POST' });
    } catch (error) {
      console.error("[ClientDashboard] Error solicitando conexión:", error);
    }
  };

  // Solicitar desvinculación y cierre de sesión de WhatsApp
  const handleDisconnectWhatsApp = async () => {
    if (!confirm("¿Estás seguro de que deseas desvincular este dispositivo de WhatsApp? Se cerrará la sesión actual en el servidor y tendrás que escanear un nuevo código QR para volver a conectar.")) {
      return;
    }

    try {
      await fetch('/api/whatsapp/logout', { method: 'POST' });
    } catch (error) {
      console.error("[ClientDashboard] Error solicitando desvinculación:", error);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('logo', file);

    try {
      const res = await fetch(`/api/clients/${clientId}/logo`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: formData
      });
      const json = await res.json();
      if (json.success) {
        alert('Logotipo de la empresa cargado correctamente.');
        // Recargar info
        const clientRes = await fetch(`/api/clients/${clientId}`);
        const clientJson = await clientRes.json();
        if (clientJson.success) {
          setClientData(clientJson.data);
        }
      } else {
        alert(json.error || 'Error al subir logotipo.');
      }
    } catch (err) {
      console.error("Error uploading logo:", err);
      alert('Error de red al subir el logotipo.');
    }
  };

  const fetchClientInfo = async () => {
    try {
      const clientRes = await fetch(`/api/clients/${clientId}`);
      const clientJson = await clientRes.json();
      if (clientJson.success) {
        setClientData(clientJson.data);
        setSystemPrompt(clientJson.data.systemPrompt);
        setAgentPhone(clientJson.data.agentPhone || '');
        setDriveFolderId(clientJson.data.driveFolderId || '');
        setCategory(clientJson.data.category || 'optica');
        
        // Cargar archivos de entrenamiento (Google Drive + Local)
        setLoadingFiles(true);
        const filesRes = await fetch(`/api/clients/${clientId}/files`);
        const filesJson = await filesRes.json();
        if (filesJson.success) {
          setUploadedFiles(filesJson.data || []);
        }
      }
    } catch (error) {
      console.error("[ClientDashboard] Error cargando cliente:", error);
    } finally {
      setLoading(false);
      setLoadingFiles(false);
    }
  };

  // Cargar datos estáticos del Cliente (Solo al iniciar o cambiar de ID)
  useEffect(() => {
    fetchClientInfo();
    fetchAgents();
    fetchAudios();
  }, [clientId]);

  // Polling dinámico (Cada 3 segundos) para Logs y Estado de Vinculación QR
  useEffect(() => {
    const fetchLiveUpdates = async () => {
      try {
        // 1. Obtener logs reales de la base de datos
        const logsRes = await fetch(`/api/clients/${clientId}/logs`);
        const logsJson = await logsRes.json();
        if (logsJson.success) {
          setInteractions(logsJson.data);
        }

        // 2. Obtener estado en tiempo real de WhatsApp
        const waRes = await fetch('/api/whatsapp/status');
        const waJson = await waRes.json();
        if (waJson.success) {
          setWhatsappStatus(waJson.data);
        }
      } catch (error) {
        console.error("[ClientDashboard] Error en polling:", error);
      }
    };

    fetchLiveUpdates(); // Carga inicial
    const interval = setInterval(fetchLiveUpdates, 3000); // Polling de 3 segundos
    return () => clearInterval(interval);
  }, [clientId]);

  // Guardar configuración del Bot
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientData) return;

    try {
      const res = await fetch(`/api/clients/${clientId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_prompt: systemPrompt,
          agent_phone: agentPhone || null,
          drive_folder_id: driveFolderId || null,
          category: category,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        // Recargar datos
        const clientRes = await fetch(`/api/clients/${clientId}`);
        const clientJson = await clientRes.json();
        if (clientJson.success) {
          setClientData(clientJson.data);
          setSystemPrompt(clientJson.data.systemPrompt);
          setAgentPhone(clientJson.data.agentPhone || '');
          setDriveFolderId(clientJson.data.driveFolderId || '');
          setCategory(clientJson.data.category || 'optica');
        }
      }
    } catch (error) {
      console.error("[ClientDashboard] Error guardando config:", error);
    }
  };

  // Función para guardar el número de teléfono del bot de forma directa
  const handleSavePhoneNumber = async () => {
    if (!tempPhone) return;
    try {
      const res = await fetch(`/api/clients/${clientId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone_number: tempPhone.replace(/\D/g, ''), // Limpiar no numéricos
        }),
      });
      const data = await res.json();
      if (data.success) {
        setIsEditingPhone(false);
        // Recargar datos
        const clientRes = await fetch(`/api/clients/${clientId}`);
        const clientJson = await clientRes.json();
        if (clientJson.success) {
          setClientData(clientJson.data);
        }
      } else {
        alert(`Error: ${data.message || data.error || 'No se pudo guardar el número'}`);
      }
    } catch (error: any) {
      console.error("[ClientDashboard] Error guardando teléfono del bot:", error);
      alert("Error de conexión al guardar el número de teléfono.");
    }
  };

  // Cargar listado de archivos cargados desde el servidor
  const fetchUploadedFiles = async () => {
    try {
      setLoadingFiles(true);
      const res = await fetch(`/api/clients/${clientId}/files`);
      const json = await res.json();
      if (json.success) {
        setUploadedFiles(json.data || []);
      }
    } catch (error) {
      console.error("[ClientDashboard] Error cargando lista de archivos:", error);
    } finally {
      setLoadingFiles(false);
    }
  };

  // Cargar archivo a Google Drive y auto-vectorizar
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const formData = new FormData();
    formData.append('file', file);

    try {
      setUploadingFile(true);
      setSyncResult(null);
      
      const res = await fetch(`/api/clients/${clientId}/upload`, {
        method: 'POST',
        body: formData,
      });

      const json = await res.json();
      if (json.success) {
        setSyncResult(`¡Archivo '${file.name}' cargado a Google Drive y vectorizado en pgvector con éxito!`);
        fetchUploadedFiles(); // Recargar listado en UI
      } else {
        setSyncResult(`Error subiendo archivo: ${json.error || json.message}`);
      }
    } catch (error) {
      console.error("[ClientDashboard] Error cargando archivo:", error);
      setSyncResult("Error de conexión al subir el archivo.");
    } finally {
      setUploadingFile(false);
    }
  };

  // Función para sincronizar la carpeta de Google Drive
  const handleSyncDrive = async () => {
    if (!driveFolderId) {
      alert("Por favor ingresa un ID de carpeta de Google Drive primero.");
      return;
    }

    try {
      setSyncingDrive(true);
      setSyncResult(null);
      const res = await fetch(`/api/clients/${clientId}/sync-drive`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSyncResult(data.message || "Sincronización completada con éxito.");
      } else {
        setSyncResult(`Error: ${data.message || data.error || 'Fallo desconocido'}`);
      }
    } catch (error: any) {
      console.error("[ClientDashboard] Error en sincronización de Drive:", error);
      setSyncResult(`Error de conexión: ${error.message || 'No se pudo conectar al servidor'}`);
    } finally {
      setSyncingDrive(false);
      setTimeout(() => setSyncResult(null), 6000);
    }
  };

  if (loading && !clientData) {
    return (
      <div className="flex justify-center items-center min-h-screen text-on-surface-variant font-body-lg">
        Cargando Panel del Inquilino...
      </div>
    );
  }

  if (!clientData) {
    return (
      <div className="p-8 text-center text-error min-h-screen">
        <h3 className="font-headline-md">Error: Cliente no encontrado</h3>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-primary text-on-primary rounded-xl cursor-pointer">Volver</button>
      </div>
    );
  }

  // Métricas reales calculadas de las interacciones
  const totalChats = interactions.length;
  const apiCostSum = interactions.reduce((acc, curr) => acc + parseFloat(curr.api_cost || "0"), 0);
  const hoursSaved = (totalChats * 3 / 60).toFixed(1);

  // Determinar el estatus del canal de WhatsApp (normalizando a últimos 10 dígitos)
  const cleanPhone = (phone: string) => phone.replace(/\D/g, '').slice(-10);
  const isWaConnected = whatsappStatus.status === 'CONNECTED' && 
    cleanPhone(whatsappStatus.phone) === cleanPhone(clientData.phoneNumber);

  return (
    <div className="flex min-h-screen bg-background text-on-surface transition-colors duration-200">
      {/* Sidebar Navigation */}
      <aside className="h-screen w-64 fixed left-0 top-0 bg-surface-container border-r border-outline/20 flex flex-col py-6 px-6 z-50">
        {/* Header/Logo Empresa */}
        <div className="flex items-center gap-3 py-4 mb-8">
          {clientData?.logo_url ? (
            <img 
              src={clientData.logo_url} 
              alt="Logo" 
              className="w-10 h-10 rounded-xl object-contain bg-white/5 border border-outline/10 p-0.5" 
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
              {clientData?.name.substring(0, 2).toUpperCase()}
            </div>
          )}
          <div className="truncate">
            <h1 className="font-bold text-sm text-on-surface truncate leading-snug">{clientData?.name}</h1>
            <p className="text-[9px] text-on-surface-variant font-mono uppercase tracking-widest">SaaS ERP</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex-grow space-y-1.5 overflow-y-auto custom-scrollbar">
          <button 
            onClick={() => setActiveTab('resumen')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'resumen' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">smart_toy</span>
            <span className="font-bold text-xs">Agente &amp; QR</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('inventario')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'inventario' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">inventory_2</span>
            <span className="font-bold text-xs">Inventario</span>
          </button>

          <button 
            onClick={() => setActiveTab('facturacion')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'facturacion' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">receipt_long</span>
            <span className="font-bold text-xs">Facturas &amp; Cobros</span>
          </button>

          <button 
            onClick={() => setActiveTab('agenda')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'agenda' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">calendar_month</span>
            <span className="font-bold text-xs">
              {clientData?.category === 'restaurante' ? 'Reservas de Mesa' :
               clientData?.category === 'optica' ? 'Citas Oftálmicas' : 'Agenda Citas'}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('empleados')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'empleados' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">groups</span>
            <span className="font-bold text-xs">Personal &amp; Turnos</span>
          </button>

          <button 
            onClick={() => setActiveTab('clientes')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'clientes' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">contacts</span>
            <span className="font-bold text-xs">
              {clientData?.category === 'optica' ? 'Pacientes (CRM)' : 'Clientes (CRM)'}
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('logs')}
            className={`w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans transition-all duration-200 ${
              activeTab === 'logs' ? 'bg-primary/10 text-primary sidebar-item-active' : 'text-on-surface-variant hover:bg-surface-variant/40 bg-transparent'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">build</span>
            <span className="font-bold text-xs">Estado del Sistema</span>
          </button>
        </nav>

        {/* Back / Logout footer */}
        <div className="border-t border-outline/10 pt-4 mt-auto">
          <button 
            onClick={onBack}
            className="w-full text-left flex items-center gap-3 p-3 rounded-xl border-0 cursor-pointer font-sans text-on-surface-variant hover:bg-surface-variant/40 bg-transparent transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">arrow_back</span>
            <span className="font-bold text-xs">Regresar</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-grow pl-64 min-h-screen flex flex-col">
        {/* Header Bar */}
        <header className="h-16 border-b border-outline/10 flex items-center justify-between px-8 bg-surface-container/20 backdrop-blur sticky top-0 z-40">
          <div>
            <h2 className="font-bold text-sm text-on-surface flex items-center gap-2">
              <span className="font-sans">
                {activeTab === 'resumen' ? '🤖 Resumen y Agente IA' :
                 activeTab === 'inventario' ? '📦 Inventario de Tienda' :
                 activeTab === 'facturacion' ? '🧾 Facturación y Carteras' :
                 activeTab === 'agenda' ? (
                   clientData?.category === 'restaurante' ? '📅 Reservación de Mesas' :
                   clientData?.category === 'optica' ? '📅 Citas Clínicas y Optometría' : '📅 Calendario de Citas'
                 ) :
                 activeTab === 'empleados' ? '👥 Gestión de Personal y Nómina' :
                 activeTab === 'clientes' ? (
                   clientData?.category === 'optica' ? '💼 CRM & Directorio de Pacientes' : '💼 CRM & Directorio de Clientes'
                 ) :
                 '⚙️ Estado del Sistema'}
              </span>
              
              {/* Dynamic Connection Indicator */}
              {activeTab === 'resumen' && (
                isWaConnected ? (
                  <span className="flex items-center gap-1 px-2 py-0.5 bg-green-500/10 text-green-500 text-[10px] font-bold rounded-full border border-green-500/20">
                    Bot En Línea
                  </span>
                ) : (
                  <span className="flex items-center gap-1 px-2 py-0.5 bg-red-500/10 text-red-500 text-[10px] font-bold rounded-full border border-red-500/20">
                    Bot Desconectado
                  </span>
                )
              )}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {/* Theme selector toggle */}
            <button 
              onClick={toggleTheme}
              className="w-9 h-9 rounded-full bg-surface-container/50 hover:bg-surface-container border border-outline/20 flex items-center justify-center cursor-pointer transition text-on-surface"
              title="Cambiar Tema"
            >
              <span className="material-symbols-outlined text-[18px]">
                {theme === 'light' ? 'dark_mode' : 'light_mode'}
              </span>
            </button>

            {/* Business Logo/Profile badge */}
            <div className="flex items-center gap-2">
              <div className="text-right hidden sm:block">
                <p className="font-label-md text-xs font-bold text-on-surface">{clientData.name}</p>
                <p className="text-[9px] text-on-surface-variant uppercase tracking-tighter">Panel de Gestión</p>
              </div>
              {clientData?.logo_url ? (
                <img 
                  src={clientData.logo_url} 
                  alt="Perfil" 
                  className="w-8 h-8 rounded-full object-contain bg-white/5 border border-outline/20 p-0.5" 
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs">
                  {clientData?.name.substring(0, 2).toUpperCase()}
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Content Container */}
        <main className="flex-grow p-8">

        {activeTab === 'resumen' && (
          <>
            {/* Bento Grid: Metrics & QR */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-10">
          {/* ROI Metrics Cards */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Metric 1 */}
            <div className="glass-card p-6 rounded-xl flex flex-col justify-between">
              <div>
                <span className="material-symbols-outlined text-primary mb-3">forum</span>
                <p className="font-label-md text-label-md text-on-surface-variant">Chats Atendidos</p>
              </div>
              <div className="mt-4">
                <h2 className="font-headline-lg text-headline-lg font-bold">{totalChats}</h2>
                <p className="text-secondary font-label-sm text-label-sm">Acumulado: ${apiCostSum.toFixed(6)} USD</p>
              </div>
            </div>

            {/* Metric 2 */}
            <div className="glass-card p-6 rounded-xl flex flex-col items-center justify-center text-center">
              <div className="relative w-24 h-24 mb-3">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle className="text-surface-container-highest stroke-current" cx="50" cy="50" fill="transparent" r="40" strokeWidth="8"></circle>
                  <circle className="text-secondary stroke-current progress-ring-circle" cx="50" cy="50" fill="transparent" r="40" strokeDasharray="251.2" strokeDashoffset="45.2" strokeLinecap="round" strokeWidth="8"></circle>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-headline-md text-headline-md font-bold">100%</span>
                </div>
              </div>
              <p className="font-label-md text-label-md text-on-surface-variant">Tasa de Respuesta IA</p>
            </div>

            {/* Metric 3 */}
            <div className="glass-card p-6 rounded-xl flex flex-col justify-between ambient-glow-primary border-primary-container/20">
              <div>
                <span className="material-symbols-outlined text-primary mb-3">timer</span>
                <p className="font-label-md text-label-md text-on-surface-variant">Tiempo Ahorrado</p>
              </div>
              <div className="mt-4">
                <h2 className="font-headline-lg text-headline-lg font-bold">{hoursSaved} Horas</h2>
                <p className="text-primary font-label-sm text-label-sm">Eficiencia de automatización</p>
              </div>
            </div>

            {/* Wide Config Summary */}
            <div className="md:col-span-3 glass-card p-6 rounded-xl flex flex-col md:flex-row items-center gap-6 relative overflow-hidden">
              <div className="flex-1 z-10">
                <h3 className="font-headline-md text-headline-md mb-2">Optimizador Inteligente Activo</h3>
                <p className="font-body-md text-body-md text-on-surface-variant max-w-xl">
                  Tu asistente de IA está gestionando actualmente consultas en tiempo real. Configura su comportamiento para mejorar la experiencia de tus usuarios.
                </p>
              </div>
              <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-primary-container/10 rounded-full blur-3xl"></div>
            </div>
          </div>

          {/* WhatsApp QR Card */}
          <div className="lg:col-span-4 glass-card p-6 rounded-xl flex flex-col items-center justify-between">
            <h3 className="font-headline-md text-headline-md mb-4 self-start">Vinculación de WhatsApp</h3>
            
            {/* Renderizado dinámico del QR o Estado */}
            <div className="relative p-3 bg-white rounded-xl mb-4 w-44 h-44 overflow-hidden flex items-center justify-center">
              {isWaConnected ? (
                <div className="text-surface font-bold text-center text-xs p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-5xl text-secondary mb-2 animate-bounce">check_circle</span>
                  <span className="text-on-secondary-fixed-variant">DISPOSITIVO VINCULADO</span>
                  <span className="text-[10px] text-gray-500 font-normal mt-1">Listo para operar</span>
                </div>
              ) : whatsappStatus.status === 'QR' ? (
                <img 
                  alt="Código QR de WhatsApp" 
                  className="w-full h-full object-cover" 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(whatsappStatus.qr)}`}
                />
              ) : whatsappStatus.status === 'INITIALIZING' ? (
                <div className="text-surface font-bold text-center text-xs p-2 flex flex-col items-center">
                  <span className="material-symbols-outlined text-4xl text-gray-400 mb-2 animate-spin">refresh</span>
                  <span className="text-gray-600">INICIALIZANDO CANAL</span>
                  <span className="text-[9px] text-gray-400 font-normal mt-1">Espera un momento...</span>
                </div>
              ) : (
                <div className="text-surface font-bold text-center text-xs p-2 flex flex-col items-center justify-center">
                  <span className="material-symbols-outlined text-4xl text-gray-400 mb-1">sync_disabled</span>
                  <span className="text-gray-600 uppercase mb-3 text-[10px] tracking-wider">Sin Vinculación Activa</span>
                  <button 
                    onClick={handleConnectWhatsApp}
                    className="bg-primary-container text-on-primary-container px-3 py-1.5 rounded-lg text-[11px] font-bold hover:opacity-90 active:scale-95 transition-all cursor-pointer"
                  >
                    Generar Código QR
                  </button>
                </div>
              )}
              {!isWaConnected && whatsappStatus.status === 'QR' && <div className="scan-line"></div>}
            </div>

            <div className="w-full space-y-2 mb-2">
              <div className="flex justify-between items-center px-1">
                <span className="font-label-md text-label-md text-on-surface-variant">Estado del Canal</span>
                <span className={`font-bold text-label-md ${isWaConnected ? 'text-secondary' : 'text-error'}`}>
                  {isWaConnected ? 'Conectado' : whatsappStatus.status === 'QR' ? 'Esperando Escaneo' : 'Fuera de Línea'}
                </span>
              </div>
              <div className="flex justify-between items-center px-1">
                <span className="font-label-md text-label-md text-on-surface-variant">Línea Asignada</span>
                {isEditingPhone ? (
                  <div className="flex items-center gap-1 bg-surface-container/60 p-1 rounded border border-outline/10">
                    <span className="text-on-surface-variant font-bold text-xs select-none">+</span>
                    <input
                      type="text"
                      className="bg-transparent text-xs font-mono w-24 text-on-surface outline-none border-b border-primary/30 focus:border-primary"
                      value={tempPhone}
                      onChange={(e) => setTempPhone(e.target.value)}
                    />
                    <button 
                      onClick={handleSavePhoneNumber}
                      className="p-0.5 hover:bg-secondary/20 text-secondary rounded transition-colors flex items-center justify-center cursor-pointer"
                      title="Guardar Número"
                    >
                      <span className="material-symbols-outlined text-[15px] font-bold">check</span>
                    </button>
                    <button 
                      onClick={() => setIsEditingPhone(false)}
                      className="p-0.5 hover:bg-error/20 text-error rounded transition-colors flex items-center justify-center cursor-pointer"
                      title="Cancelar"
                    >
                      <span className="material-symbols-outlined text-[15px]">close</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 group/phone">
                    <span className="text-on-surface font-label-md font-mono">+{clientData.phoneNumber}</span>
                    <button
                      onClick={() => {
                        setTempPhone(clientData.phoneNumber);
                        setIsEditingPhone(true);
                      }}
                      className="p-1 text-on-surface-variant/40 hover:text-primary hover:bg-surface-variant/50 rounded transition-all flex items-center justify-center opacity-0 group-hover/phone:opacity-100 focus:opacity-100 cursor-pointer"
                      title="Editar Línea"
                    >
                      <span className="material-symbols-outlined text-[14px]">edit</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
            {isWaConnected && (
              <button 
                onClick={handleDisconnectWhatsApp}
                className="mt-2 w-full bg-error/15 text-error border border-error/20 px-4 py-2.5 rounded-xl text-xs font-bold hover:bg-error/25 hover:text-white transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-[0.98]"
              >
                <span className="material-symbols-outlined text-[16px]">logout</span>
                Desvincular WhatsApp
              </button>
            )}
            {!isWaConnected && whatsappStatus.status === 'QR' && (
              <p className="text-[10.5px] text-center text-primary/80 font-medium px-2">
                Escanea el código QR desde la opción "Dispositivos vinculados" en tu aplicación móvil de WhatsApp.
              </p>
            )}
            {!isWaConnected && (whatsappStatus.status === 'QR' || whatsappStatus.status === 'INITIALIZING') && (
              <div className="w-full space-y-2 mt-2">
                <button 
                  onClick={async () => {
                    if (confirm("¿Deseas cancelar la conexión actual y generar un nuevo código QR?")) {
                      try {
                        // 1. Cerrar sesión previa y limpiar almacenamiento local
                        await fetch('/api/whatsapp/logout', { method: 'POST' });
                        // 2. Esperar a que Puppeteer se apague y borre los archivos
                        await new Promise(resolve => setTimeout(resolve, 1500));
                        // 3. Arrancar una conexión nueva limpia
                        await fetch(`/api/whatsapp/connect?clientId=${clientId}`, { method: 'POST' });
                      } catch (err) {
                        console.error("Error al reiniciar conexión:", err);
                      }
                    }
                  }}
                  className="w-full bg-surface-container border border-outline/30 hover:border-primary/50 text-on-surface-variant hover:text-primary px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-[0.98]"
                >
                  <span className="material-symbols-outlined text-[16px]">refresh</span>
                  Generar Nuevo QR
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Config Panel */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
          <div className="lg:col-span-2 glass-card p-6 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <span className="material-symbols-outlined text-primary-container">smart_toy</span>
              <h3 className="font-headline-md text-headline-md">Configuración del Agente IA</h3>
            </div>
            <form onSubmit={handleSaveConfig} className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="font-label-md text-label-md text-on-surface-variant">Comportamiento &amp; Instrucciones (System Prompt)</label>
                  <span className="text-[11px] text-primary font-medium">Define el rol y reglas del bot</span>
                </div>
                <textarea 
                  className="w-full bg-surface-container border border-outline/30 rounded-lg p-3 text-body-md focus:border-primary-container focus:ring-1 focus:ring-primary-container transition-all min-h-[140px] text-on-surface"
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  placeholder="Define cómo debe responder la IA... Ej: Eres un recepcionista amable de la Clínica Dental. Tu objetivo es agendar citas."
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <label className="font-label-md text-label-md text-on-surface-variant">Línea del Asesor Humano (Traspaso)</label>
                  <input 
                    className="w-full bg-surface-container border border-outline/30 rounded-lg p-3 text-body-md focus:border-primary-container focus:ring-1 focus:ring-primary-container text-on-surface font-mono"
                    type="text"
                    value={agentPhone}
                    onChange={(e) => setAgentPhone(e.target.value)}
                    placeholder="Ej: 573009998888"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-label-md text-label-md text-on-surface-variant">Tono de Voz del Bot</label>
                  <select 
                    className="w-full bg-surface-container border border-outline/30 rounded-lg p-3 text-body-md focus:border-primary-container focus:ring-1 focus:ring-primary-container text-on-surface"
                    value={toneOfVoice}
                    onChange={(e) => setToneOfVoice(e.target.value)}
                  >
                    <option value="Friendly">Amistoso (Recomendado)</option>
                    <option value="Formal">Formal y Corporativo</option>
                    <option value="Casual">Casual e Informal</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="font-label-md text-label-md text-on-surface-variant">Categoría del Negocio</label>
                  <select 
                    className="w-full bg-surface-container border border-outline/30 rounded-lg p-3 text-body-md focus:border-primary-container focus:ring-1 focus:ring-primary-container text-on-surface"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    <option value="optica">👓 Óptica / Centro Clínico</option>
                    <option value="restaurante">🍕 Restaurante / Alimentos</option>
                    <option value="otros">🎮 General / Videojuegos / Retail</option>
                  </select>
                </div>
              </div>

              {/* Sección RAG de Google Drive */}
              <div className="border-t border-outline/10 pt-4 mt-6 space-y-3">
                <h4 className="font-label-md text-label-md font-bold text-primary flex items-center gap-2">
                  <span className="material-symbols-outlined text-[20px]">cloud_sync</span>
                  Base de Conocimientos (Entrenamiento del Bot)
                </h4>
                <p className="text-xs text-on-surface-variant opacity-75">
                  El bot utiliza la información contenida en los documentos cargados para responder a tus clientes de forma precisa y contextual.
                </p>

                {/* ID de Carpeta de Google Drive - Oculto para el cliente por ser un campo técnico */}
                <input 
                  type="hidden"
                  value={driveFolderId}
                />

                <div className="flex justify-between items-center gap-4 bg-surface-container/20 p-3 rounded-lg border border-outline/5">
                  <span className="text-xs text-on-surface-variant">
                    Sincroniza los archivos de tu carpeta de entrenamiento en la nube.
                  </span>
                  <button
                    type="button"
                    onClick={handleSyncDrive}
                    disabled={syncingDrive || !driveFolderId}
                    className="bg-secondary-container text-on-secondary-container px-4 py-2.5 rounded-lg font-bold text-xs hover:scale-[1.02] transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:scale-100 cursor-pointer active:scale-95 shrink-0"
                  >
                    <span className={`material-symbols-outlined text-[16px] ${syncingDrive ? 'animate-spin' : ''}`}>
                      {syncingDrive ? 'sync' : 'cloud_download'}
                    </span>
                    {syncingDrive ? 'Sincronizando...' : 'Sincronizar Base de Datos'}
                  </button>
                </div>
                {syncResult && (
                  <div className={`p-3 rounded-lg text-xs font-semibold transition-all border ${
                    syncResult.includes('Error') 
                      ? 'bg-error/15 text-error border-error/20' 
                      : 'bg-secondary/15 text-secondary border-secondary/20'
                  }`}>
                    {syncResult}
                  </div>
                )}

                 {/* Visualizador y Carga de Archivos RAG */}
                <div className="bg-surface-container/30 border border-outline/10 rounded-lg p-4 space-y-3 mt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-primary">menu_book</span>
                      Documentos de Entrenamiento (RAG)
                    </span>
                    {loadingFiles && <span className="text-[10px] text-primary animate-pulse">Cargando archivos...</span>}
                  </div>
                  
                  {uploadedFiles.length === 0 ? (
                    <p className="text-xs text-on-surface-variant opacity-60 italic text-center py-4 bg-surface-container/10 rounded-lg">
                      Aún no has subido documentos. ¡Sube un archivo de texto o PDF para entrenar a tu bot!
                    </p>
                  ) : (
                    <div className="max-h-40 overflow-y-auto divide-y divide-outline/5 pr-1 space-y-1 bg-surface-container/20 p-2 rounded-lg">
                      {uploadedFiles.map((file) => (
                        <div key={file.id} className="flex items-center justify-between text-xs py-1.5 first:pt-0">
                          <div className="flex items-center gap-2 truncate pr-2">
                            <span className="material-symbols-outlined text-[16px] text-primary/70 shrink-0">
                              {file.mimeType.includes('folder') ? 'folder' : 'description'}
                            </span>
                            <span className="text-on-surface truncate font-medium" title={file.name}>{file.name}</span>
                          </div>
                          <span className="text-[10px] text-on-surface-variant opacity-60 shrink-0 font-mono bg-surface-container-highest px-1.5 py-0.5 rounded">
                            {file.mimeType.includes('text/plain') 
                              ? 'TXT' 
                              : file.mimeType.includes('google-apps.document') 
                                ? 'Doc' 
                                : file.mimeType.includes('pdf') 
                                  ? 'PDF' 
                                  : 'Doc'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Zona de Carga de Archivos */}
                  <div className="pt-1">
                    <label className="relative flex items-center justify-center border border-dashed border-outline/30 rounded-lg p-3 hover:bg-surface-container-high/40 hover:border-primary/50 transition-all cursor-pointer text-center text-xs font-semibold text-on-surface-variant gap-2 active:scale-[0.99]">
                      <span className="material-symbols-outlined text-[18px] text-primary">
                        {uploadingFile ? 'sync' : 'upload_file'}
                      </span>
                      <span>
                        {uploadingFile ? 'Subiendo y vectorizando...' : 'Subir archivo de entrenamiento (PDF, TXT, DOCX)'}
                      </span>
                      <input 
                        type="file" 
                        accept=".txt,.pdf,.docx" 
                        className="hidden" 
                        disabled={uploadingFile || syncingDrive} 
                        onChange={handleFileUpload} 
                      />
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4 items-center gap-4">
                {saveSuccess && (
                  <span className="text-secondary font-bold text-sm flex items-center gap-1">
                    <span className="material-symbols-outlined text-[18px]">check_circle</span>
                    ¡Configuración guardada!
                  </span>
                )}
                <button 
                  className="bg-primary-container text-on-primary-container px-6 py-2.5 rounded-lg font-bold font-label-md text-label-md flex items-center gap-2 hover:scale-[1.02] transition-transform active:scale-95 cursor-pointer"
                  type="submit"
                >
                  <span className="material-symbols-outlined">save</span>
                  Guardar Cambios
                </button>
              </div>
            </form>

            {/* Gestión de Asesores Humanos */}
            <div className="glass-card p-6 rounded-xl mt-6">
              <div className="flex items-center gap-2 mb-4">
                <span className="material-symbols-outlined text-secondary">groups</span>
                <h3 className="font-headline-md text-headline-md">Gestión de Asesores Humanos (Cascada)</h3>
              </div>
              
              <p className="text-xs text-on-surface-variant opacity-75 mb-6">
                Registra los teléfonos y nombres de tus asesores en orden de prioridad. 
                Si un asesor no responde en 1 minuto, Frant escalará la llamada al siguiente asesor activo de la lista.
              </p>

              {/* List of current agents */}
              <div className="space-y-3 mb-6">
                {loadingAgents ? (
                  <div className="text-center text-xs text-primary animate-pulse py-4">Cargando asesores...</div>
                ) : agents.length === 0 ? (
                  <p className="text-xs text-on-surface-variant opacity-60 italic text-center py-4 bg-surface-container/10 rounded-lg">
                    Aún no has agregado asesores humanos. ¡Agrega uno abajo para habilitar el traspaso!
                  </p>
                ) : (
                  <div className="bg-surface-container/30 border border-outline/10 rounded-lg overflow-hidden divide-y divide-outline/5">
                    {agents.map((agent) => (
                      <div key={agent.id} className="flex items-center justify-between p-3.5 text-xs hover:bg-surface-container/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">
                            {agent.priority}
                          </span>
                          <div>
                            <p className="font-bold text-on-surface">{agent.name}</p>
                            <p className="text-[11px] text-on-surface-variant font-mono">+{agent.phone}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {/* Toggle Status Button */}
                          <button
                            type="button"
                            onClick={() => handleToggleAgentStatus(agent.id, agent.status)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                              agent.status === 'online'
                                ? 'bg-secondary/15 text-secondary border-secondary/20 hover:bg-secondary/25'
                                : 'bg-outline/15 text-on-surface-variant border-outline/20 hover:bg-outline/25'
                            }`}
                          >
                            {agent.status === 'online' ? '● En Línea' : '○ Ausente'}
                          </button>
                          
                          {/* Delete Button */}
                          <button
                            type="button"
                            onClick={() => handleDeleteAgent(agent.id)}
                            className="p-1.5 hover:bg-error/20 text-error/80 hover:text-error rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                            title="Eliminar asesor"
                          >
                            <span className="material-symbols-outlined text-[16px]">delete</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Add new agent form */}
              <form onSubmit={handleAddAgent} className="bg-surface-container/20 border border-outline/5 rounded-lg p-4 space-y-4">
                <span className="text-[11px] font-bold text-secondary uppercase tracking-wider flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">person_add</span>
                  Agregar Nuevo Asesor
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="font-label-md text-label-md text-on-surface-variant">Nombre del Asesor</label>
                    <input
                      type="text"
                      required
                      value={newAgentName}
                      onChange={(e) => setNewAgentName(e.target.value)}
                      placeholder="Ej: Carlos"
                      className="w-full bg-surface-container border border-outline/30 rounded-lg p-2.5 text-xs text-on-surface focus:border-primary-container focus:ring-1 focus:ring-primary-container outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-label-md text-label-md text-on-surface-variant">Teléfono (WhatsApp)</label>
                    <input
                      type="text"
                      required
                      value={newAgentPhone}
                      onChange={(e) => setNewAgentPhone(e.target.value)}
                      placeholder="Ej: 573009998888"
                      className="w-full bg-surface-container border border-outline/30 rounded-lg p-2.5 text-xs text-on-surface focus:border-primary-container focus:ring-1 focus:ring-primary-container font-mono outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-label-md text-label-md text-on-surface-variant">Prioridad (Orden)</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={newAgentPriority}
                      onChange={(e) => setNewAgentPriority(parseInt(e.target.value) || 1)}
                      className="w-full bg-surface-container border border-outline/30 rounded-lg p-2.5 text-xs text-on-surface focus:border-primary-container focus:ring-1 focus:ring-primary-container outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={!newAgentName || !newAgentPhone}
                    className="bg-secondary-container text-on-secondary-container px-4 py-2 rounded-lg font-bold text-xs hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:scale-100 transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[16px]">add_circle</span>
                    Agregar a la Lista
                  </button>
                </div>
              </form>
            </div>

            {/* Gestión de Audios Pregrabados */}
            <div className="glass-card p-6 rounded-xl mt-6">
              <div className="flex items-center gap-2 mb-4">
                <span className="material-symbols-outlined text-secondary">mic</span>
                <h3 className="font-headline-md text-headline-md">Notas de Voz Pregrabadas (Audios)</h3>
              </div>
              
              <p className="text-xs text-on-surface-variant opacity-75 mb-6">
                Sube las notas de voz de tu negocio (ej. bienvenida, horarios, despedida) en formato MP3, WAV u OGG.
                Frant enviará estos archivos directamente como notas de voz nativas en WhatsApp.
              </p>

              {/* Lista de audios existentes */}
              <div className="space-y-3 mb-6">
                {loadingAudios ? (
                  <div className="text-center text-xs text-primary animate-pulse py-4">Cargando audios...</div>
                ) : audios.length === 0 ? (
                  <p className="text-xs text-on-surface-variant opacity-60 italic text-center py-4 bg-surface-container/10 rounded-lg">
                    Aún no has subido notas de voz pregrabadas. ¡Sube una abajo!
                  </p>
                ) : (
                  <div className="bg-surface-container/30 border border-outline/10 rounded-lg overflow-hidden divide-y divide-outline/5">
                    {audios.map((audio) => (
                      <div key={audio.fileName} className="flex flex-col md:flex-row md:items-center justify-between p-3.5 gap-3 text-xs hover:bg-surface-container/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <span className="material-symbols-outlined text-[20px] text-primary">audiotrack</span>
                          <div>
                            <p className="font-bold text-on-surface">Etiqueta: <span className="text-secondary">'{audio.tag}'</span></p>
                            <p className="text-[10px] text-on-surface-variant opacity-70 truncate font-mono" title={audio.fileName}>
                              {audio.fileName} ({(audio.size / 1024).toFixed(1)} KB)
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3 justify-end shrink-0">
                          {/* Reproductor de Audio Nativo HTML5 */}
                          <audio 
                            src={audio.url} 
                            controls 
                            className="h-7 w-44 md:w-52 filter dark:invert"
                          />
                          
                          {/* Botón de Eliminar */}
                          <button
                            type="button"
                            onClick={() => handleDeleteAudio(audio.fileName)}
                            className="p-1.5 hover:bg-error/20 text-error/80 hover:text-error rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                            title="Eliminar audio"
                          >
                            <span className="material-symbols-outlined text-[16px]">delete</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Formulario de carga de audio */}
              <form onSubmit={handleUploadAudio} className="bg-surface-container/20 border border-outline/5 rounded-lg p-4 space-y-4">
                <span className="text-[11px] font-bold text-secondary uppercase tracking-wider flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">upload</span>
                  Subir Nueva Nota de Voz
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-label-md text-label-md text-on-surface-variant">Etiqueta / Nombre del Audio</label>
                    <input
                      type="text"
                      required
                      value={newAudioTag}
                      onChange={(e) => setNewAudioTag(e.target.value)}
                      placeholder="Ej: bienvenida, horarios, traspaso"
                      className="w-full bg-surface-container border border-outline/30 rounded-lg p-2.5 text-xs text-on-surface focus:border-primary-container focus:ring-1 focus:ring-primary-container outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-label-md text-label-md text-on-surface-variant">Archivo de Audio (MP3, WAV, OGG)</label>
                    <input
                      type="file"
                      id="audio-file-input"
                      required
                      accept="audio/*"
                      onChange={(e) => setAudioFile(e.target.files?.[0] || null)}
                      className="w-full bg-surface-container border border-outline/30 rounded-lg p-2.5 text-xs text-on-surface focus:border-primary-container focus:ring-1 focus:ring-primary-container outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={uploadingAudio || !newAudioTag || !audioFile}
                    className="bg-secondary-container text-on-secondary-container px-4 py-2 rounded-lg font-bold text-xs hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:scale-100 transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[16px]">
                      {uploadingAudio ? 'sync' : 'cloud_upload'}
                    </span>
                    {uploadingAudio ? 'Subiendo...' : 'Subir Audio'}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            {/* Logo Upload Card */}
            <div className="glass-card p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-3">
                <span className="material-symbols-outlined text-secondary">image</span>
                <h3 className="font-bold text-sm text-on-surface">Logotipo Comercial</h3>
              </div>
              <p className="text-xs text-on-surface-variant mb-4 font-sans leading-relaxed">
                Sube el logotipo de tu empresa. Se mostrará en el menú lateral y en tus facturas.
              </p>
              <div className="flex items-center gap-4">
                {clientData?.logo_url ? (
                  <img 
                    src={clientData.logo_url} 
                    alt="Logo Empresa" 
                    className="w-16 h-16 rounded-xl object-contain bg-white/5 border border-outline/20 p-1"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-primary/10 border border-dashed border-primary/30 flex items-center justify-center text-primary font-bold text-lg font-sans">
                    {clientData?.name.substring(0, 2).toUpperCase()}
                  </div>
                )}
                <div>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleLogoUpload}
                    className="hidden" 
                    id="logo-upload-input" 
                  />
                  <label 
                    htmlFor="logo-upload-input"
                    className="px-3 py-2 bg-surface-container border border-outline/20 hover:border-primary/50 text-on-surface text-xs font-bold rounded-xl cursor-pointer transition inline-flex items-center gap-1.5 font-sans"
                  >
                    <span className="material-symbols-outlined text-[16px]">upload</span>
                    Subir Logotipo
                  </label>
                </div>
              </div>
            </div>

            <div className="glass-card p-6 rounded-xl ambient-glow-secondary border-secondary/20">
              <h4 className="font-label-md text-label-md font-bold text-secondary mb-4 uppercase">Atención Requerida</h4>
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <div className="w-8 h-8 rounded-full bg-error/20 flex items-center justify-center text-error shrink-0">
                    <span className="material-symbols-outlined text-sm">priority_high</span>
                  </div>
                  <div>
                    <p className="font-label-md text-label-md">Consulta de Urgencia</p>
                    <p className="text-[12px] text-on-surface-variant">El usuario solicita hablar con un asesor por dolor severo.</p>
                  </div>
                </div>
                <button className="w-full py-2 bg-surface-container-high/50 border border-outline/20 rounded-lg text-sm font-medium hover:bg-surface-container-high transition-all cursor-pointer">
                  Atender Ahora
                </button>
              </div>
            </div>
            <div className="glass-card p-6 rounded-xl overflow-hidden relative">
              <div className="relative z-10">
                <h4 className="font-label-md text-label-md font-bold mb-4">Estado del Agente IA</h4>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex-1 h-2 bg-surface-container rounded-full overflow-hidden">
                    <div className="h-full bg-primary-container w-[92%]"></div>
                  </div>
                  <span className="text-xs font-bold">92%</span>
                </div>
                <p className="text-[11px] text-on-surface-variant">El modelo de lenguaje está optimizado y listo para responder.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Chat History Table */}
        <section className="glass-card rounded-xl overflow-hidden">
          <div className="p-6 border-b border-outline/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <h3 className="font-headline-md text-headline-md">Historial de Conversaciones</h3>
              <p className="font-label-md text-label-md text-on-surface-variant">Registro en tiempo real de interacciones</p>
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-md">search</span>
                <input className="bg-surface-container border border-outline/30 rounded-lg py-1.5 pl-10 pr-4 text-sm focus:border-primary-container focus:ring-0 text-on-surface w-64" placeholder="Buscar mensaje..." type="text"/>
              </div>
              <button className="material-symbols-outlined p-2 border border-outline/30 rounded-lg hover:bg-surface-container/30">filter_list</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-surface-container-high/50 text-on-surface-variant">
                  <th className="px-6 py-3 font-label-md text-label-md uppercase tracking-wider">Usuario</th>
                  <th className="px-6 py-3 font-label-md text-label-md uppercase tracking-wider">Último Mensaje</th>
                  <th className="px-6 py-3 font-label-md text-label-md uppercase tracking-wider">Respuesta de Frant (Bot)</th>
                  <th className="px-6 py-3 font-label-md text-label-md uppercase tracking-wider">Tipo</th>
                  <th className="px-6 py-3 font-label-md text-label-md uppercase tracking-wider">Costo / Hora</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline/10">
                {interactions.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-6 text-on-surface-variant italic">No hay interacciones registradas aún. Envía un mensaje de WhatsApp para verlos aquí.</td>
                  </tr>
                ) : interactions.map((log, index) => (
                  <tr key={index} className="hover:bg-primary-container/5 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary-container/20 flex items-center justify-center text-primary font-bold text-xs">
                          {log.sender_phone.substring(0, 2)}
                        </div>
                        <div>
                          <p className="font-label-md text-label-md font-bold">Usuario</p>
                          <p className="text-[10px] text-on-surface-variant font-mono">+{log.sender_phone}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 max-w-xs">
                      <p className="text-sm truncate">{log.message_text}</p>
                    </td>
                    <td className="px-6 py-4 max-w-xs">
                      <p className="text-sm truncate italic text-primary-container/80">{log.response_text}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-[10px] font-bold border ${
                        parseFloat(log.api_cost) > 0 
                          ? 'bg-secondary/10 text-secondary border-secondary/20' 
                          : 'bg-tertiary/10 text-tertiary border-tertiary/20'
                      }`}>
                        {parseFloat(log.api_cost) > 0 ? 'RESPUESTA IA' : 'HUMANO'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-xs font-bold">${parseFloat(log.api_cost).toFixed(6)}</p>
                        <p className="text-[10px] text-on-surface-variant">{new Date(log.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
          </>
        )}

        {activeTab === 'inventario' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SaaSErpInventory clientId={clientId} />
          </div>
        )}

        {activeTab === 'facturacion' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SaaSErpInvoices clientId={clientId} />
          </div>
        )}

        {activeTab === 'agenda' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SaaSErpAppointments clientId={clientId} />
          </div>
        )}

        {activeTab === 'empleados' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SaaSErpEmployees clientId={clientId} />
          </div>
        )}

        {activeTab === 'clientes' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SaaSErpCRM clientId={clientId} />
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="glass-card p-6 rounded-2xl border border-outline/10">
            <SystemAlertsPanel clientId={clientId} />
          </div>
        )}
      </main>
    </div>
  </div>
);
};
