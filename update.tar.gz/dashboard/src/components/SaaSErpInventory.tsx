import React, { useState, useEffect } from 'react';

interface Product {
    id: string;
    name: string;
    sku: string | null;
    description: string | null;
    price: string;
    stock: number;
    created_at: string;
}

interface SaaSErpInventoryProps {
    clientId: string;
}

export const SaaSErpInventory: React.FC<SaaSErpInventoryProps> = ({ clientId }) => {
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);

    // Form fields
    const [name, setName] = useState('');
    const [sku, setSku] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState(0);
    const [stock, setStock] = useState(0);

    const token = localStorage.getItem('auth_token');

    const fetchProducts = async () => {
        try {
            setLoading(true);
            const res = await fetch(`/api/clients/${clientId}/products`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) {
                setProducts(json.products || []);
            }
        } catch (err) {
            console.error("Error loading products:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProducts();
    }, [clientId]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const body = { name, sku, description, price, stock };

        try {
            const url = editingProduct 
                ? `/api/clients/${clientId}/products/${editingProduct.id}`
                : `/api/clients/${clientId}/products`;
            const method = editingProduct ? 'PUT' : 'POST';

            const res = await fetch(url, {
                method,
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(body)
            });
            const data = await res.json();

            if (data.success) {
                fetchProducts();
                resetForm();
            } else {
                alert(`Error: ${data.error}`);
            }
        } catch (err) {
            alert('Error al guardar el producto.');
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('¿Estás seguro de eliminar este producto?')) return;
        try {
            const res = await fetch(`/api/clients/${clientId}/products/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                fetchProducts();
            } else {
                alert(`Error: ${data.error}`);
            }
        } catch (err) {
            alert('Error al eliminar producto.');
        }
    };

    const openEdit = (prod: Product) => {
        setEditingProduct(prod);
        setName(prod.name);
        setSku(prod.sku || '');
        setDescription(prod.description || '');
        setPrice(parseFloat(prod.price));
        setStock(prod.stock);
        setIsFormOpen(true);
    };

    const resetForm = () => {
        setEditingProduct(null);
        setName('');
        setSku('');
        setDescription('');
        setPrice(0);
        setStock(0);
        setIsFormOpen(false);
    };

    const formatPrice = (val: string) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency', currency: 'COP', minimumFractionDigits: 0
        }).format(parseFloat(val));
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold">Catálogo de Inventario</h2>
                    <p className="text-xs text-gray-400">Administra los productos, lentes y monturas del negocio.</p>
                </div>
                <button
                    onClick={() => { resetForm(); setIsFormOpen(true); }}
                    className="bg-[#0a5cff] hover:bg-[#0047d4] text-white text-xs font-bold py-2 px-4 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                    <span className="material-symbols-outlined text-[16px]">add</span>
                    Agregar Producto
                </button>
            </div>

            {isFormOpen && (
                <div className="bg-[#0d1527] border border-white/10 rounded-2xl p-6 space-y-4">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">
                        {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
                    </h3>
                    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs text-gray-400 font-medium">Nombre del Producto *</label>
                            <input 
                                type="text"
                                className="bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:border-[#0a5cff] outline-none transition"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                            />
                        </div>
                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs text-gray-400 font-medium">SKU / Código Único</label>
                            <input 
                                type="text"
                                className="bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:border-[#0a5cff] outline-none transition"
                                value={sku}
                                onChange={(e) => setSku(e.target.value)}
                            />
                        </div>
                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs text-gray-400 font-medium">Precio de Venta (COP) *</label>
                            <input 
                                type="number"
                                className="bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:border-[#0a5cff] outline-none transition"
                                value={price}
                                onChange={(e) => setPrice(parseFloat(e.target.value))}
                                required
                            />
                        </div>
                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs text-gray-400 font-medium">Stock en Existencias *</label>
                            <input 
                                type="number"
                                className="bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:border-[#0a5cff] outline-none transition"
                                value={stock}
                                onChange={(e) => setStock(parseInt(e.target.value))}
                                required
                            />
                        </div>
                        <div className="flex flex-col gap-1.5 md:col-span-2">
                            <label className="text-xs text-gray-400 font-medium">Descripción</label>
                            <textarea 
                                className="bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:border-[#0a5cff] outline-none transition min-h-[80px]"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                            />
                        </div>
                        <div className="md:col-span-2 flex justify-end gap-3 pt-2">
                            <button
                                type="button"
                                onClick={resetForm}
                                className="bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-bold py-2 px-4 rounded-xl transition cursor-pointer"
                            >
                                Cancelar
                            </button>
                            <button
                                type="submit"
                                className="bg-[#0a5cff] hover:bg-[#0047d4] text-white text-xs font-bold py-2 px-4 rounded-xl transition cursor-pointer"
                            >
                                {editingProduct ? 'Actualizar' : 'Guardar'}
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {loading ? (
                <div className="flex justify-center py-10">
                    <div className="w-8 h-8 border-2 border-[#0a5cff] border-t-transparent rounded-full animate-spin"></div>
                </div>
            ) : products.length === 0 ? (
                <div className="bg-[#090d16] border border-white/5 p-12 text-center rounded-2xl">
                    <p className="text-sm text-gray-500">No hay productos registrados en el inventario aún.</p>
                </div>
            ) : (
                <div className="bg-[#0d1527]/50 border border-white/10 rounded-2xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-white/5 border-b border-white/10 text-xs text-gray-400 uppercase font-bold">
                                <th className="p-4">Producto</th>
                                <th className="p-4">SKU</th>
                                <th className="p-4">Precio</th>
                                <th className="p-4">Stock</th>
                                <th className="p-4 text-right">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-sm">
                            {products.map((prod) => (
                                <tr key={prod.id} className="hover:bg-white/5 transition-colors">
                                    <td className="p-4">
                                        <p className="font-bold text-white">{prod.name}</p>
                                        {prod.description && <p className="text-xs text-gray-400 mt-0.5">{prod.description}</p>}
                                    </td>
                                    <td className="p-4 font-mono text-xs">{prod.sku || '-'}</td>
                                    <td className="p-4 font-semibold text-white">{formatPrice(prod.price)}</td>
                                    <td className="p-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${prod.stock < 5 ? 'bg-red-500/10 text-red-400' : 'bg-green-500/10 text-green-400'}`}>
                                            {prod.stock} uds
                                        </span>
                                    </td>
                                    <td className="p-4 text-right">
                                        <div className="flex justify-end gap-1.5">
                                            <button 
                                                onClick={() => openEdit(prod)}
                                                className="p-1.5 hover:bg-[#0a5cff]/20 text-[#0a5cff] rounded transition cursor-pointer"
                                                title="Editar"
                                            >
                                                <span className="material-symbols-outlined text-[16px]">edit</span>
                                            </button>
                                            <button 
                                                onClick={() => handleDelete(prod.id)}
                                                className="p-1.5 hover:bg-red-500/20 text-red-400 rounded transition cursor-pointer"
                                                title="Eliminar"
                                            >
                                                <span className="material-symbols-outlined text-[16px]">delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};
