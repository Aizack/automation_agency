import React, { useState, useEffect } from 'react';

interface Employee {
    id: string;
    name: string;
    phone: string;
    role: string;
    department_id: string | null;
    department_name: string | null;
    pin: string;
    is_active: boolean;
    created_at: string;
}

interface Department {
    id: string;
    name: string;
    created_at: string;
}

interface Shift {
    id: string;
    clock_in: string;
    clock_out: string | null;
    hours_worked: number;
}

interface SaaSErpEmployeesProps {
    clientId: string;
}

export const SaaSErpEmployees: React.FC<SaaSErpEmployeesProps> = ({ clientId }) => {
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [departments, setDepartments] = useState<Department[]>([]);
    const [loading, setLoading] = useState(true);

    // Modals
    const [isDeptOpen, setIsDeptOpen] = useState(false);
    const [isEmpOpen, setIsEmpOpen] = useState(false);
    const [isClockOpen, setIsClockOpen] = useState(false);
    const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);
    const [empShifts, setEmpShifts] = useState<Shift[]>([]);
    const [shiftsLoading, setShiftsLoading] = useState(false);

    // Form inputs
    const [deptName, setDeptName] = useState('');
    const [empName, setEmpName] = useState('');
    const [empPhone, setEmpPhone] = useState('');
    const [empRole, setEmpRole] = useState('agent');
    const [empDeptId, setEmpDeptId] = useState('');
    const [empPin, setEmpPin] = useState('1234');
    const [clockPin, setClockPin] = useState('');

    const [errorMsg, setErrorMsg] = useState('');
    const [actionLoading, setActionLoading] = useState(false);

    const token = localStorage.getItem('auth_token');

    const fetchData = async () => {
        try {
            setLoading(true);
            const headers = { 'Authorization': `Bearer ${token}` };
            
            const [empRes, deptRes] = await Promise.all([
                fetch(`/api/clients/${clientId}/employees`, { headers }),
                fetch(`/api/clients/${clientId}/departments`, { headers })
            ]);

            const empJson = await empRes.json();
            const deptJson = await deptRes.json();

            if (empJson.success) setEmployees(empJson.employees || []);
            if (deptJson.success) setDepartments(deptJson.departments || []);
        } catch (err) {
            console.error("Error loading employees data:", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [clientId]);

    const handleCreateDept = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!deptName) return;

        try {
            setActionLoading(true);
            setErrorMsg('');
            const res = await fetch(`/api/clients/${clientId}/departments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ name: deptName })
            });
            const json = await res.json();
            if (json.success) {
                setDeptName('');
                setIsDeptOpen(false);
                fetchData();
            } else {
                setErrorMsg(json.error || 'Error al guardar departamento.');
            }
        } catch (err: any) {
            setErrorMsg(err.message || 'Error de conexión.');
        } finally {
            setActionLoading(false);
        }
    };

    const handleDeleteDept = async (id: string, name: string) => {
        if (!window.confirm(`¿Estás seguro de eliminar el departamento "${name}"?`)) return;
        try {
            const res = await fetch(`/api/clients/${clientId}/departments/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) {
                fetchData();
            }
        } catch (err) {
            console.error("Error deleting department:", err);
        }
    };

    const handleCreateEmp = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!empName || !empPhone) {
            setErrorMsg('Nombre y teléfono son requeridos.');
            return;
        }

        try {
            setActionLoading(true);
            setErrorMsg('');
            
            const url = selectedEmp 
                ? `/api/clients/${clientId}/employees/${selectedEmp.id}`
                : `/api/clients/${clientId}/employees`;
            
            const method = selectedEmp ? 'PUT' : 'POST';

            const res = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    name: empName,
                    phone: empPhone,
                    role: empRole,
                    department_id: empDeptId || null,
                    pin: empPin,
                    is_active: true
                })
            });
            const json = await res.json();
            if (json.success) {
                setIsEmpOpen(false);
                fetchData();
            } else {
                setErrorMsg(json.error || 'Error al guardar empleado.');
            }
        } catch (err: any) {
            setErrorMsg(err.message || 'Error de conexión.');
        } finally {
            setActionLoading(false);
        }
    };

    const handleDeleteEmp = async (id: string, name: string) => {
        if (!window.confirm(`¿Estás seguro de eliminar el empleado "${name}"?`)) return;
        try {
            const res = await fetch(`/api/clients/${clientId}/employees/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) {
                fetchData();
            }
        } catch (err) {
            console.error("Error deleting employee:", err);
        }
    };

    const openCreateEmpModal = () => {
        setSelectedEmp(null);
        setEmpName('');
        setEmpPhone('');
        setEmpRole('agent');
        setEmpDeptId('');
        setEmpPin('1234');
        setErrorMsg('');
        setIsEmpOpen(true);
    };

    const openEditEmpModal = (emp: Employee) => {
        setSelectedEmp(emp);
        setEmpName(emp.name);
        setEmpPhone(emp.phone);
        setEmpRole(emp.role);
        setEmpDeptId(emp.department_id || '');
        setEmpPin(emp.pin);
        setErrorMsg('');
        setIsEmpOpen(true);
    };

    // Timesheet shifts modal
    const openClockModal = async (emp: Employee) => {
        setSelectedEmp(emp);
        setClockPin('');
        setErrorMsg('');
        setIsClockOpen(true);
        loadShifts(emp.id);
    };

    const loadShifts = async (empId: string) => {
        try {
            setShiftsLoading(true);
            const res = await fetch(`/api/clients/${clientId}/employees/${empId}/shifts`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) {
                setEmpShifts(json.shifts || []);
            }
        } catch (err) {
            console.error("Error loading shifts:", err);
        } finally {
            setShiftsLoading(false);
        }
    };

    const handleClockAction = async (action: 'in' | 'out') => {
        if (!selectedEmp) return;
        if (clockPin !== selectedEmp.pin) {
            setErrorMsg('PIN de seguridad incorrecto.');
            return;
        }

        try {
            setActionLoading(true);
            setErrorMsg('');
            const res = await fetch(`/api/clients/${clientId}/employees/${selectedEmp.id}/clock-${action}`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) {
                setClockPin('');
                loadShifts(selectedEmp.id);
            } else {
                setErrorMsg(json.error || `Error al marcar ${action === 'in' ? 'entrada' : 'salida'}.`);
            }
        } catch (err: any) {
            setErrorMsg(err.message || 'Error de conexión.');
        } finally {
            setActionLoading(false);
        }
    };

    // Calculate aggregated adoption stats
    const activeShiftsCount = empShifts.filter(s => !s.clock_out).length;
    const totalHours = empShifts.reduce((acc, curr) => acc + Number(curr.hours_worked || 0), 0);

    return (
        <div className="space-y-6 text-on-surface">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-xl font-bold text-on-surface">Gestión de Empleados y Nómina</h2>
                    <p className="text-xs text-on-surface-variant">Registra departamentos, crea asesores de atención y controla turnos de trabajo con marcación.</p>
                </div>
                <div className="flex items-center gap-3">
                    <button 
                        onClick={() => { setErrorMsg(''); setDeptName(''); setIsDeptOpen(true); }}
                        className="px-4 py-2 border border-outline/20 hover:bg-surface-variant/20 text-on-surface text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition"
                    >
                        <span className="material-symbols-outlined text-[16px]">domain</span>
                        Departamentos
                    </button>
                    <button 
                        onClick={openCreateEmpModal}
                        className="px-4 py-2 bg-primary hover:bg-primary-container text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow transition"
                    >
                        <span className="material-symbols-outlined text-[16px]">person_add</span>
                        Nuevo Empleado
                    </button>
                </div>
            </div>

            {loading ? (
                <div className="flex justify-center py-20">
                    <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Employees list table */}
                    <div className="lg:col-span-8 bg-surface-container/30 border border-outline/10 rounded-2xl p-6 overflow-x-auto">
                        <h3 className="font-bold text-sm text-on-surface mb-4">Listado de Personal</h3>
                        {employees.length === 0 ? (
                            <p className="text-sm text-on-surface-variant text-center py-6">No hay empleados registrados en el sistema.</p>
                        ) : (
                            <table className="w-full text-left text-xs border-collapse">
                                <thead>
                                    <tr className="border-b border-outline/10 text-on-surface-variant uppercase font-bold tracking-tight">
                                        <th className="py-3 px-2">Nombre</th>
                                        <th className="py-3 px-2">Teléfono</th>
                                        <th className="py-3 px-2">Rol / Cargo</th>
                                        <th className="py-3 px-2">Departamento</th>
                                        <th className="py-3 px-2">PIN</th>
                                        <th className="py-3 px-2 text-right">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {employees.map(emp => (
                                        <tr key={emp.id} className="border-b border-outline/5 hover:bg-surface-variant/20 transition-all">
                                            <td className="py-3.5 px-2 font-bold text-on-surface">{emp.name}</td>
                                            <td className="py-3.5 px-2 font-mono">+{emp.phone}</td>
                                            <td className="py-3.5 px-2">
                                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                                                    emp.role === 'admin' ? 'bg-secondary/15 text-secondary' : 'bg-primary/10 text-primary'
                                                }`}>
                                                    {emp.role.toUpperCase()}
                                                </span>
                                            </td>
                                            <td className="py-3.5 px-2 text-on-surface-variant">{emp.department_name || 'Sin Asignar'}</td>
                                            <td className="py-3.5 px-2 font-mono">••••</td>
                                            <td className="py-3.5 px-2 text-right space-x-1.5">
                                                <button 
                                                    onClick={() => openClockModal(emp)}
                                                    className="px-2.5 py-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-500 border-0 rounded-lg text-[10px] font-bold cursor-pointer transition"
                                                >
                                                    Turnos
                                                </button>
                                                <button 
                                                    onClick={() => openEditEmpModal(emp)}
                                                    className="p-1.5 text-on-surface hover:bg-surface-variant/40 rounded-lg border-0 cursor-pointer transition-all inline-flex"
                                                >
                                                    <span className="material-symbols-outlined text-[16px]">edit</span>
                                                </button>
                                                <button 
                                                    onClick={() => handleDeleteEmp(emp.id, emp.name)}
                                                    className="p-1.5 text-red-500 hover:bg-red-500/10 rounded-lg border-0 cursor-pointer transition-all inline-flex"
                                                >
                                                    <span className="material-symbols-outlined text-[16px]">delete</span>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>

                    {/* Quick Stats & Adoption overview */}
                    <div className="lg:col-span-4 space-y-6">
                        {/* Adoption Stats Card */}
                        <div className="bg-surface-container/30 border border-outline/10 p-6 rounded-2xl">
                            <h3 className="font-bold text-sm text-on-surface mb-3">Métricas de Adopción</h3>
                            <div className="space-y-4">
                                <div className="flex justify-between items-center p-3.5 bg-surface-container/50 border border-outline/10 rounded-xl">
                                    <div className="flex items-center gap-2">
                                        <span className="material-symbols-outlined text-primary">groups</span>
                                        <span className="text-xs text-on-surface-variant">Asesores Totales</span>
                                    </div>
                                    <span className="font-bold text-sm">{employees.length}</span>
                                </div>

                                <div className="flex justify-between items-center p-3.5 bg-surface-container/50 border border-outline/10 rounded-xl">
                                    <div className="flex items-center gap-2">
                                        <span className="material-symbols-outlined text-green-500">work</span>
                                        <span className="text-xs text-on-surface-variant">Turnos Activos Hoy</span>
                                    </div>
                                    <span className="font-bold text-sm text-green-500">
                                        {employees.filter(e => e.is_active).length}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Shift quick check-in instructions helper */}
                        <div className="bg-primary/5 border border-primary/10 p-6 rounded-2xl text-xs space-y-2">
                            <h4 className="font-bold text-primary flex items-center gap-1.5">
                                <span className="material-symbols-outlined text-[16px]">info</span>
                                Marcación Rápida
                            </h4>
                            <p className="text-on-surface-variant leading-relaxed">
                                Los empleados pueden marcar su entrada y salida directamente en esta pantalla digitando su PIN secreto. Esto mantendrá activa su sesión y calculará sus horas laboradas.
                            </p>
                        </div>
                    </div>
                </div>
            )}

            {/* DEPARTMENTS MANAGER MODAL */}
            {isDeptOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div className="glass-card max-w-md w-full rounded-2xl overflow-hidden p-6 shadow-2xl">
                        <div className="flex justify-between items-center border-b border-outline/10 pb-3 mb-4">
                            <h3 className="font-bold text-lg text-on-surface">Gestionar Departamentos</h3>
                            <button 
                                onClick={() => setIsDeptOpen(false)}
                                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-variant/40 border-0 cursor-pointer text-on-surface"
                            >
                                <span className="material-symbols-outlined text-[20px]">close</span>
                            </button>
                        </div>

                        {errorMsg && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-xs p-3 rounded-xl mb-4 font-bold">
                                ⚠️ {errorMsg}
                            </div>
                        )}

                        {/* Add department form */}
                        <form onSubmit={handleCreateDept} className="flex gap-2 mb-4">
                            <input 
                                type="text"
                                required
                                value={deptName}
                                onChange={(e) => setDeptName(e.target.value)}
                                className="flex-grow bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface text-xs focus:border-primary outline-none"
                                placeholder="Ej: Cartera, Recepción..."
                            />
                            <button 
                                type="submit"
                                disabled={actionLoading}
                                className="px-4 py-2.5 bg-primary hover:bg-primary-container text-white text-xs font-bold rounded-xl cursor-pointer transition"
                            >
                                Agregar
                            </button>
                        </form>

                        {/* Departments list */}
                        <div className="space-y-2 max-h-[250px] overflow-y-auto custom-scrollbar">
                            <h4 className="text-xs font-bold text-on-surface-variant mb-2">Departamentos Activos</h4>
                            {departments.length === 0 ? (
                                <p className="text-xs text-on-surface-variant/60 py-3 text-center">No hay departamentos creados.</p>
                            ) : (
                                departments.map(d => (
                                    <div key={d.id} className="flex justify-between items-center bg-surface-container/30 border border-outline/5 p-3 rounded-xl">
                                        <span className="text-xs font-bold">{d.name}</span>
                                        <button 
                                            onClick={() => handleDeleteDept(d.id, d.name)}
                                            className="p-1 text-red-500 hover:bg-red-500/10 border-0 rounded cursor-pointer transition-all inline-flex"
                                        >
                                            <span className="material-symbols-outlined text-[16px]">delete</span>
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* CREATE/EDIT EMPLOYEE MODAL */}
            {isEmpOpen && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div className="glass-card max-w-md w-full rounded-2xl overflow-hidden p-6 shadow-2xl">
                        <div className="flex justify-between items-center border-b border-outline/10 pb-3 mb-4">
                            <h3 className="font-bold text-lg text-on-surface">
                                {selectedEmp ? 'Editar Empleado' : 'Registrar Empleado'}
                            </h3>
                            <button 
                                onClick={() => setIsEmpOpen(false)}
                                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-variant/40 border-0 cursor-pointer text-on-surface"
                            >
                                <span className="material-symbols-outlined text-[20px]">close</span>
                            </button>
                        </div>

                        {errorMsg && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-xs p-3 rounded-xl mb-4 font-bold">
                                ⚠️ {errorMsg}
                            </div>
                        )}

                        <form onSubmit={handleCreateEmp} className="space-y-4 text-sm">
                            <div className="space-y-1">
                                <label className="block text-xs font-bold text-on-surface-variant">Nombre Completo</label>
                                <input 
                                    type="text"
                                    required
                                    value={empName}
                                    onChange={(e) => setEmpName(e.target.value)}
                                    className="w-full bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface focus:border-primary outline-none"
                                    placeholder="Ej: Laura Bermúdez"
                                />
                            </div>

                            <div className="space-y-1">
                                <label className="block text-xs font-bold text-on-surface-variant">Teléfono (WhatsApp)</label>
                                <input 
                                    type="text"
                                    required
                                    value={empPhone}
                                    onChange={(e) => setEmpPhone(e.target.value)}
                                    className="w-full bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface focus:border-primary outline-none font-mono"
                                    placeholder="Ej: 573001112222"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <label className="block text-xs font-bold text-on-surface-variant">Cargo / Rol</label>
                                    <select 
                                        value={empRole}
                                        onChange={(e) => setEmpRole(e.target.value)}
                                        className="w-full bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface focus:border-primary outline-none cursor-pointer"
                                    >
                                        <option value="agent">Asesor / Agente</option>
                                        <option value="admin">Administrador</option>
                                    </select>
                                </div>

                                <div className="space-y-1">
                                    <label className="block text-xs font-bold text-on-surface-variant">Departamento</label>
                                    <select 
                                        value={empDeptId}
                                        onChange={(e) => setEmpDeptId(e.target.value)}
                                        className="w-full bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface focus:border-primary outline-none cursor-pointer"
                                    >
                                        <option value="">Ninguno</option>
                                        {departments.map(d => (
                                            <option key={d.id} value={d.id}>{d.name}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <div className="space-y-1">
                                <label className="block text-xs font-bold text-on-surface-variant">PIN de Seguridad (4 dígitos)</label>
                                <input 
                                    type="text"
                                    maxLength={4}
                                    required
                                    value={empPin}
                                    onChange={(e) => setEmpPin(e.target.value.replace(/\D/g, ''))}
                                    className="w-full bg-surface-container-high/40 border border-outline/20 p-2.5 rounded-xl text-on-surface focus:border-primary outline-none font-mono text-center tracking-widest text-base"
                                    placeholder="1234"
                                />
                            </div>

                            <div className="flex gap-3 justify-end pt-4 border-t border-outline/10">
                                <button 
                                    type="button"
                                    onClick={() => setIsEmpOpen(false)}
                                    className="px-4 py-2 border border-outline/20 text-on-surface hover:bg-surface-variant/20 rounded-xl font-bold cursor-pointer text-xs transition"
                                >
                                    Cancelar
                                </button>
                                <button 
                                    type="submit"
                                    disabled={actionLoading}
                                    className="px-4 py-2 bg-primary hover:bg-primary-container text-white rounded-xl font-bold cursor-pointer text-xs transition flex items-center gap-1 disabled:opacity-50"
                                >
                                    {actionLoading ? 'Guardando...' : 'Guardar Empleado'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* SHIFTS LOGGING & CLOCK-IN/OUT MODAL */}
            {isClockOpen && selectedEmp && (
                <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div className="glass-card max-w-xl w-full rounded-2xl overflow-hidden p-6 shadow-2xl">
                        <div className="flex justify-between items-center border-b border-outline/10 pb-3 mb-4">
                            <div className="text-left">
                                <h3 className="font-bold text-lg text-on-surface">Historial de Turnos</h3>
                                <p className="text-[10px] text-on-surface-variant font-mono">Empleado: {selectedEmp.name}</p>
                            </div>
                            <button 
                                onClick={() => setIsClockOpen(false)}
                                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-variant/40 border-0 cursor-pointer text-on-surface"
                            >
                                <span className="material-symbols-outlined text-[20px]">close</span>
                            </button>
                        </div>

                        {errorMsg && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-500 text-xs p-3 rounded-xl mb-4 font-bold">
                                ⚠️ {errorMsg}
                            </div>
                        )}

                        {/* PIN validation area to perform shift clocks */}
                        <div className="bg-surface-container/50 border border-outline/10 p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
                            <div className="space-y-1 w-full md:w-auto">
                                <label className="block text-[10px] font-bold text-on-surface-variant uppercase">PIN del Empleado</label>
                                <input 
                                    type="password"
                                    maxLength={4}
                                    value={clockPin}
                                    onChange={(e) => setClockPin(e.target.value.replace(/\D/g, ''))}
                                    className="bg-surface border border-outline/20 px-3 py-2 rounded-xl text-on-surface font-mono tracking-widest text-center text-sm outline-none focus:border-primary w-24"
                                    placeholder="••••"
                                />
                            </div>
                            <div className="flex gap-3 w-full md:w-auto">
                                <button 
                                    onClick={() => handleClockAction('in')}
                                    disabled={actionLoading}
                                    className="flex-grow md:flex-none px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer transition shadow"
                                >
                                    <span className="material-symbols-outlined text-[16px]">login</span>
                                    Iniciar Turno
                                </button>
                                <button 
                                    onClick={() => handleClockAction('out')}
                                    disabled={actionLoading}
                                    className="flex-grow md:flex-none px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer transition shadow"
                                >
                                    <span className="material-symbols-outlined text-[16px]">logout</span>
                                    Cerrar Turno
                                </button>
                            </div>
                        </div>

                        {/* Summary metrics for this employee */}
                        <div className="flex justify-between items-center mb-4 text-xs font-bold bg-primary/5 p-3 rounded-xl border border-primary/10">
                            <span className="text-on-surface-variant">Turnos Activos: <span className="text-green-500">{activeShiftsCount}</span></span>
                            <span className="text-on-surface-variant">Horas Totales: <span className="text-primary">{totalHours.toFixed(2)} Hrs</span></span>
                        </div>

                        {/* Shifts listing grid */}
                        <div className="space-y-2 max-h-[220px] overflow-y-auto custom-scrollbar">
                            <h4 className="text-xs font-bold text-on-surface-variant mb-2">Turnos Recientes</h4>
                            {shiftsLoading ? (
                                <div className="flex justify-center py-6">
                                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                                </div>
                            ) : empShifts.length === 0 ? (
                                <p className="text-xs text-on-surface-variant/60 py-3 text-center">No hay registros de marcación para este empleado.</p>
                            ) : (
                                empShifts.map(s => (
                                    <div key={s.id} className="flex justify-between items-center bg-surface-container/30 border border-outline/5 p-3 rounded-xl text-xs">
                                        <div className="space-y-1">
                                            <div className="flex items-center gap-1">
                                                <span className="material-symbols-outlined text-green-500 text-[14px]">login</span>
                                                <span className="font-bold">{new Date(s.clock_in).toLocaleString('es-CO')}</span>
                                            </div>
                                            <div className="flex items-center gap-1 text-on-surface-variant">
                                                <span className="material-symbols-outlined text-orange-500 text-[14px]">logout</span>
                                                <span>{s.clock_out ? new Date(s.clock_out).toLocaleString('es-CO') : <span className="text-green-500 font-bold">Activo</span>}</span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold text-primary font-mono">{Number(s.hours_worked || 0).toFixed(2)} Hrs</p>
                                            <p className="text-[9px] text-on-surface-variant">Horas Trabajadas</p>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
