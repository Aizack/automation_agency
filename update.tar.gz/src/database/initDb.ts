import { pool } from './postgres';

const initDatabase = async () => {
    console.log("[DB Init] 🔄 Inicializando base de datos en PostgreSQL...");

    try {
        // 1. Crear extensión UUID en caso de que no exista
        await pool.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`);
        console.log("[DB Init] ✅ Extensión uuid-ossp lista.");

        // 2. Crear tabla clients (con credenciales de acceso y drive_folder_id)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS clients (
                id VARCHAR(50) PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                phone_number VARCHAR(20) UNIQUE NOT NULL,
                system_prompt TEXT NOT NULL,
                active_tools TEXT[] DEFAULT '{}',
                status VARCHAR(20) DEFAULT 'active',
                agent_phone VARCHAR(20),
                drive_folder_id VARCHAR(100),
                username VARCHAR(50) UNIQUE,
                password VARCHAR(100),
                email VARCHAR(100),
                contact_name VARCHAR(100),
                owner_phone VARCHAR(20),
                first_message_notified BOOLEAN DEFAULT FALSE,
                is_activated BOOLEAN DEFAULT FALSE,
                category VARCHAR(50) DEFAULT 'optica',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        
        // Ejecutar alter table por si la tabla ya existía sin estas columnas
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS agent_phone VARCHAR(20);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS drive_folder_id VARCHAR(100);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS username VARCHAR(50) UNIQUE;`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS password VARCHAR(100);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS email VARCHAR(100);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS contact_name VARCHAR(100);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS owner_phone VARCHAR(20);`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS first_message_notified BOOLEAN DEFAULT FALSE;`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS is_activated BOOLEAN DEFAULT FALSE;`);
        await pool.query(`ALTER TABLE clients ADD COLUMN IF NOT EXISTS category VARCHAR(50) DEFAULT 'optica';`);
        console.log("[DB Init] ✅ Tabla 'clients' creada y alterada con columnas de Login, agent_phone, drive_folder_id, owner_phone, first_message_notified, is_activated y category.");

        // 3. Crear tabla interactions (Métricas)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS interactions (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                sender_phone VARCHAR(20) NOT NULL,
                message_text TEXT NOT NULL,
                response_text TEXT NOT NULL,
                tokens_input INT DEFAULT 0,
                tokens_output INT DEFAULT 0,
                api_cost NUMERIC(10, 6) DEFAULT 0.000000,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'interactions' creada o ya existente.");

        // 4. Crear tabla takeover_sessions (Traspaso Humano)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS takeover_sessions (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                customer_phone VARCHAR(20) NOT NULL,
                status VARCHAR(20) DEFAULT 'active', -- 'active' (IA pausada), 'closed' (IA activa)
                current_agent_phone VARCHAR(20),
                escalation_index INT DEFAULT 0,
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                interacted_with_agent BOOLEAN DEFAULT FALSE,
                customer_name VARCHAR(100) DEFAULT 'Cliente',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'takeover_sessions' creada o ya existente.");

        // 4.1 Crear tabla agent_contacts (Lista jerárquica de asesores)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS agent_contacts (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                name VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                priority INT NOT NULL,
                status VARCHAR(20) DEFAULT 'online', -- 'online', 'offline'
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(client_id, phone)
            );
        `);
        // Ejecutar alter table por si la columna department no existe
        await pool.query(`ALTER TABLE agent_contacts ADD COLUMN IF NOT EXISTS department VARCHAR(30) DEFAULT 'recepcion';`);
        await pool.query(`ALTER TABLE agent_contacts ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE;`);
        await pool.query(`ALTER TABLE agent_contacts ADD COLUMN IF NOT EXISTS role VARCHAR(20) DEFAULT 'agent';`);
        await pool.query(`ALTER TABLE agent_contacts ADD COLUMN IF NOT EXISTS pin VARCHAR(4) DEFAULT '1234';`);
        await pool.query(`ALTER TABLE takeover_sessions ADD COLUMN IF NOT EXISTS department VARCHAR(50) DEFAULT 'recepcion';`);
        console.log("[DB Init] ✅ Tabla 'agent_contacts' creada o ya existente, alterada con columnas department, is_verified, role y pin. Tabla 'takeover_sessions' alterada con department.");

        // 4.2 Crear tabla products (Inventario)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS products (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                name VARCHAR(100) NOT NULL,
                sku VARCHAR(50),
                description TEXT,
                price NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
                stock INT NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'products' creada o ya existente.");

        // 4.3 Tabla de Facturas (Cobro de Cartera / Factura Electrónica)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS invoices (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                invoice_number VARCHAR(50) NOT NULL,
                customer_name VARCHAR(100) NOT NULL,
                customer_phone VARCHAR(20) NOT NULL,
                customer_document_type VARCHAR(10) DEFAULT 'CC',
                customer_document_number VARCHAR(30) NOT NULL,
                customer_email VARCHAR(100) NOT NULL,
                customer_address VARCHAR(200),
                total_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                due_date TIMESTAMP NOT NULL,
                reminder_sent BOOLEAN DEFAULT FALSE,
                overdue_sent BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(client_id, invoice_number)
            );
        `);
        console.log("[DB Init] ✅ Tabla 'invoices' creada o ya existente.");

        // 4.4 Detalle de Factura
        await pool.query(`
            CREATE TABLE IF NOT EXISTS invoice_items (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
                product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
                quantity INT NOT NULL DEFAULT 1,
                price NUMERIC(10, 2) NOT NULL
            );
        `);
        console.log("[DB Init] ✅ Tabla 'invoice_items' creada o ya existente.");

        // 5. Crear tabla appointments (Agenda de citas interna)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS appointments (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                customer_phone VARCHAR(20) NOT NULL,
                customer_name VARCHAR(100) NOT NULL,
                appointment_date TIMESTAMP NOT NULL,
                status VARCHAR(20) DEFAULT 'confirmed', -- 'confirmed', 'cancelled', 'rescheduled'
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'appointments' creada o ya existente.");

        // 5.1 Crear tabla system_alerts (Alertas y Logs de Estado)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS system_alerts (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                alert_key VARCHAR(50) NOT NULL,
                severity VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                status VARCHAR(20) DEFAULT 'active', -- 'active', 'resolved'
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                resolved_at TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'system_alerts' creada o ya existente.");

        // 5.2 Modificar y crear tablas de la Fase 2 (Empleados, Turnos, CRM, OTP, etc.)
        await pool.query(`
            CREATE TABLE IF NOT EXISTS business_departments (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                name VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'business_departments' creada o ya existente.");

        await pool.query(`
            CREATE TABLE IF NOT EXISTS employees (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                name VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                role VARCHAR(30) DEFAULT 'agent', -- 'admin', 'agent'
                department_id UUID REFERENCES business_departments(id) ON DELETE SET NULL,
                pin VARCHAR(4) DEFAULT '1234',
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'employees' creada o ya existente.");

        await pool.query(`
            CREATE TABLE IF NOT EXISTS shift_logs (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
                clock_in TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                clock_out TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'shift_logs' creada o ya existente.");

        await pool.query(`
            CREATE TABLE IF NOT EXISTS crm_customers (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                name VARCHAR(100) NOT NULL,
                document_type VARCHAR(10) DEFAULT 'CC',
                document_number VARCHAR(30) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                email VARCHAR(100),
                address VARCHAR(200),
                lens_prescription TEXT,
                last_interaction_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(client_id, document_number)
            );
        `);
        console.log("[DB Init] ✅ Tabla 'crm_customers' creada o ya existente.");

        await pool.query(`
            CREATE TABLE IF NOT EXISTS phone_verifications (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                phone VARCHAR(20) NOT NULL,
                code VARCHAR(6) NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                verified BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'phone_verifications' creada o ya existente.");

        // Modificaciones incrementales
        await pool.query(`
            ALTER TABLE clients ADD COLUMN IF NOT EXISTS logo_url TEXT;
        `);
        await pool.query(`
            ALTER TABLE system_alerts ADD COLUMN IF NOT EXISTS client_id VARCHAR(50) REFERENCES clients(id) ON DELETE CASCADE;
        `);
        console.log("[DB Init] ✅ Columnas logo_url y client_id alteradas.");

        // 6. Crear tabla vector_store (pgvector para el RAG)
        await pool.query(`CREATE EXTENSION IF NOT EXISTS vector;`);
        console.log("[DB Init] ✅ Extensión vector (pgvector) lista.");

        // Eliminar tabla anterior para limpiar dimensiones antiguas de 768
        await pool.query(`DROP TABLE IF EXISTS vector_store CASCADE;`);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS vector_store (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                client_id VARCHAR(50) NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
                content TEXT NOT NULL,
                embedding vector(3072) NOT NULL,
                metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log("[DB Init] ✅ Tabla 'vector_store' (pgvector 3072 dimensiones) creada.");

        // 7. Semillar/Insertar Clientes Iniciales (Seed Data)
        const clientsToSeed = [
            {
                id: "client_001",
                name: "Clínica Dental Sonrisas",
                phone_number: "1234567890",
                system_prompt: "Eres el asistente virtual de Clínica Sonrisas. Tu objetivo es agendar citas médicas con empatía y revisar horarios.",
                active_tools: ["agendarCita", "consultarHorarios"],
                agent_phone: "573001112222", // Número del dentista humano
                category: "optica"
            },
            {
                id: "client_002",
                name: "Pizzería Napoli",
                phone_number: "0987654321",
                system_prompt: "Eres el asistente de Pizzería Napoli. Debes tomar pedidos, confirmar la dirección de envío y calcular el costo.",
                active_tools: ["crearPedido", "consultarMenu"],
                agent_phone: "573003334444", // Número del pizzero humano
                category: "restaurante"
            }
        ];

        for (const client of clientsToSeed) {
            await pool.query(`
                INSERT INTO clients (id, name, phone_number, system_prompt, active_tools, status, agent_phone, category)
                VALUES ($1, $2, $3, $4, $5, 'active', $6, $7)
                ON CONFLICT (id) DO UPDATE SET
                    name = EXCLUDED.name,
                    phone_number = EXCLUDED.phone_number,
                    system_prompt = EXCLUDED.system_prompt,
                    active_tools = EXCLUDED.active_tools,
                    agent_phone = EXCLUDED.agent_phone,
                    category = EXCLUDED.category;
            `, [client.id, client.name, client.phone_number, client.system_prompt, client.active_tools, client.agent_phone, client.category]);
        }

        console.log("[DB Init] ✅ Datos iniciales de clientes semillados correctamente.");
        console.log("[DB Init] 🎉 ¡Inicialización completada con éxito!");

    } catch (error) {
        console.error("[DB Init] ❌ Error inicializando base de datos:", error);
    } finally {
        // Cerrar el pool para que el script termine de ejecutarse en terminal
        await pool.end();
        console.log("[DB Init] 🔌 Conexiones de inicialización cerradas.");
    }
};

initDatabase();
